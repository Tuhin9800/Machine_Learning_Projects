#to run this file open-> streamlit run test.py

import streamlit as st
import pandas as pd
import numpy as np
from sklearn.neighbors import NearestNeighbors
from scipy.sparse import csr_matrix

# -----------------------------
# Load Data
# -----------------------------
@st.cache_data
def load_data():
    books = pd.read_csv("Book/BX-Books.csv", encoding='latin-1', sep=';', on_bad_lines='skip')
    ratings = pd.read_csv("Book/BX-Book-Ratings.csv", encoding='latin-1', sep=';', on_bad_lines='skip')
    books = books[['ISBN', 'Book-Title', 'Book-Author', 'Year-Of-Publication', 'Publisher', 'Image-URL-L']]
    books.rename(columns={
        'Book-Title': 'title',
        'Book-Author': 'author',
        'Year-Of-Publication': 'year',
        'Image-URL-L': 'image'
    }, inplace=True)

    x = ratings['User-ID'].value_counts() > 200
    ratings = ratings[ratings['User-ID'].isin(x[x].index)]

    rating_merged_books = ratings.merge(books, on='ISBN')
    rating_counts = rating_merged_books.groupby('title')['Book-Rating'].count().reset_index()
    final_rating = rating_merged_books.merge(rating_counts, on='title')
    final_rating = final_rating[final_rating['Book-Rating_y'] >= 50]
    final_rating.drop_duplicates(['User-ID', 'title'], inplace=True)

    book_table = final_rating.pivot_table(values='Book-Rating_x', index='title', columns='User-ID').fillna(0)
    return books, book_table

books, book_table = load_data()

# -----------------------------
# Model
# -----------------------------
book_sparse = csr_matrix(book_table.values)
model = NearestNeighbors(metric='cosine', algorithm='brute')
model.fit(book_sparse)

# -----------------------------
# Streamlit UI
# -----------------------------
st.title("📚 Book Recommendation System")

selected_book = st.selectbox("Choose a book you like:", book_table.index)

if st.button("Recommend"):
    idx = list(book_table.index).index(selected_book)
    distances, suggestions = model.kneighbors(book_table.iloc[idx, :].values.reshape(1, -1), n_neighbors=6)

    st.subheader("Top 5 Recommendations:")

    for i in range(1, 6):  # Skip the first since it's the book itself
        book_title = book_table.index[suggestions[0][i]]
        book_info = books[books['title'] == book_title].drop_duplicates('title')

        if not book_info.empty:
            book = book_info.iloc[0]
            st.markdown(f"### {book['title']}")
            st.image(book['image'], width=150)
            st.markdown(f"**Author:** {book['author']}  \n**Publisher:** {book['Publisher']}  \n**Year:** {book['year']}")
            st.markdown("---")
